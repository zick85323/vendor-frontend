import { Search, Bell, ChevronDown, RefreshCw, Plus } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"

export default function CryptoDashboard() {
  return (
    <div className="flex flex-col min-h-screen bg-white">
      {/* Header */}
      <header className="bg-[#f6b10a] text-white h-[56px] px-[16px] flex justify-between items-center">
        <div className="flex items-center">
          <div className="w-[24px] h-[24px] bg-white rounded-[4px] flex items-center justify-center mr-[8px]">
            <span className="text-[#f6b10a] font-bold text-[14px]">B</span>
          </div>
          <span className="font-bold text-[16px]">BIBUAIN</span>
        </div>
        <button className="text-white">
          <div className="space-y-[4px]">
            <div className="w-[20px] h-[2px] bg-white"></div>
            <div className="w-[20px] h-[2px] bg-white"></div>
            <div className="w-[20px] h-[2px] bg-white"></div>
          </div>
        </button>
      </header>

      {/* Search and User Info */}
      <div className="p-[16px] border-b border-[#e5e7eb]">
        <div className="relative mb-[16px]">
          <Search className="absolute left-[12px] top-1/2 transform -translate-y-1/2 text-[#9ca3af] h-[16px] w-[16px]" />
          <input
            type="text"
            placeholder="Search..."
            className="w-full pl-[36px] pr-[12px] py-[8px] border border-[#e5e7eb] rounded-[4px] text-[14px]"
          />
        </div>

        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <div className="w-[20px] h-[20px] mr-[8px]">
              <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 6V12L16 14" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                <circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="2" />
              </svg>
            </div>
            <span className="font-bold text-[14px]">03:56:03</span>
            <span className="ml-[16px] text-[#6b7280] text-[14px]">Break</span>
          </div>

          <Button
            variant="outline"
            className="border-[#ff3b30] text-[#ff3b30] ml-[8px] text-[12px] px-[12px] py-[4px] h-[28px] rounded-[4px]"
          >
            Clock Out
          </Button>

          <div className="flex items-center ml-auto">
            <Bell className="h-[16px] w-[16px] mr-[12px] text-[#9ca3af]" />
            <div className="flex items-center">
              <div className="text-right mr-[8px]">
                <div className="text-[14px] font-medium">Alex Johnson</div>
                <div className="text-[12px] text-[#6b7280]">Admin</div>
              </div>
              <div className="w-[32px] h-[32px] bg-[#f3f4f6] rounded-full"></div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="flex-1 p-[16px]">
        <h2 className="text-[20px] font-bold mb-[16px]">Coin Exchange</h2>

        {/* Tabs */}
        <Tabs defaultValue="all" className="mb-[24px]">
          <TabsList className="grid grid-cols-7 mb-[16px] h-[36px] bg-transparent p-0 gap-[8px]">
            <TabsTrigger
              value="all"
              className="text-[14px] h-[36px] data-[state=active]:bg-[#f6b10a] data-[state=active]:text-white rounded-[4px] border border-[#e5e7eb] data-[state=inactive]:bg-white data-[state=inactive]:text-black"
            >
              All Coins
            </TabsTrigger>
            <TabsTrigger
              value="binance"
              className="text-[14px] h-[36px] data-[state=active]:bg-[#f6b10a] data-[state=active]:text-white rounded-[4px] border border-[#e5e7eb] data-[state=inactive]:bg-white data-[state=inactive]:text-black"
            >
              Binance
            </TabsTrigger>
            <TabsTrigger
              value="payful"
              className="text-[14px] h-[36px] data-[state=active]:bg-[#f6b10a] data-[state=active]:text-white rounded-[4px] border border-[#e5e7eb] data-[state=inactive]:bg-white data-[state=inactive]:text-black"
            >
              Payful
            </TabsTrigger>
            <TabsTrigger
              value="nexones"
              className="text-[14px] h-[36px] data-[state=active]:bg-[#f6b10a] data-[state=active]:text-white rounded-[4px] border border-[#e5e7eb] data-[state=inactive]:bg-white data-[state=inactive]:text-black"
            >
              Nexones
            </TabsTrigger>
            <TabsTrigger
              value="bybit"
              className="text-[14px] h-[36px] data-[state=active]:bg-[#f6b10a] data-[state=active]:text-white rounded-[4px] border border-[#e5e7eb] data-[state=inactive]:bg-white data-[state=inactive]:text-black"
            >
              Bybit
            </TabsTrigger>
            <TabsTrigger
              value="kucoin"
              className="text-[14px] h-[36px] data-[state=active]:bg-[#f6b10a] data-[state=active]:text-white rounded-[4px] border border-[#e5e7eb] data-[state=inactive]:bg-white data-[state=inactive]:text-black"
            >
              KuCoin
            </TabsTrigger>
            <TabsTrigger
              value="other"
              className="text-[14px] h-[36px] data-[state=active]:bg-[#f6b10a] data-[state=active]:text-white rounded-[4px] border border-[#e5e7eb] data-[state=inactive]:bg-white data-[state=inactive]:text-black"
            >
              Other
            </TabsTrigger>
          </TabsList>
        </Tabs>

        {/* Coin Balances */}
        <div className="mb-[32px]">
          <div className="flex justify-between items-center mb-[16px]">
            <h2 className="text-[20px] font-bold">Coin Balances</h2>
            <div className="flex items-center">
              <Button
                variant="outline"
                size="sm"
                className="mr-[8px] h-[32px] text-[14px] rounded-[4px] border-[#e5e7eb]"
              >
                <RefreshCw className="h-[14px] w-[14px] mr-[4px]" />
                Refresh
              </Button>
              <Button variant="outline" size="sm" className="h-[32px] text-[14px] rounded-[4px] border-[#e5e7eb]">
                <Plus className="h-[14px] w-[14px] mr-[4px]" />
                Add
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-[16px]">
            {/* BTC Card */}
            <Card className="p-[16px] border border-[#e5e7eb] rounded-[8px] shadow-none">
              <div className="flex justify-between items-center mb-[12px]">
                <div className="flex items-center">
                  <div className="w-[20px] h-[20px] bg-[#f7931a] rounded-full mr-[8px]"></div>
                  <span className="font-bold text-[16px]">BTC</span>
                </div>
                <span className="text-[#22c55e] text-[14px]">+2.3%</span>
              </div>
              <div className="mb-[12px]">
                <div className="text-[14px] text-[#6b7280]">Balance</div>
                <div className="font-bold text-[18px]">0.45 BTC</div>
              </div>
              <div className="mb-[12px]">
                <div className="text-[14px] text-[#6b7280]">Current Rate</div>
                <div className="font-bold text-[16px]">US $62,500.00</div>
              </div>
              <div>
                <div className="text-[14px] text-[#6b7280]">Excess Coin: 0.20 BTC</div>
              </div>
            </Card>

            {/* USDT Card */}
            <Card className="p-[16px] border border-[#e5e7eb] rounded-[8px] shadow-none">
              <div className="flex justify-between items-center mb-[12px]">
                <div className="flex items-center">
                  <div className="w-[20px] h-[20px] bg-[#26a17b] rounded-full mr-[8px]"></div>
                  <span className="font-bold text-[16px]">USDT</span>
                </div>
                <span className="text-[#22c55e] text-[14px]">+0.01%</span>
              </div>
              <div className="mb-[12px]">
                <div className="text-[14px] text-[#6b7280]">Balance</div>
                <div className="font-bold text-[18px]">1,250.75 USDT</div>
              </div>
              <div className="mb-[12px]">
                <div className="text-[14px] text-[#6b7280]">Current Rate</div>
                <div className="font-bold text-[16px]">US $1.00</div>
              </div>
              <div>
                <div className="text-[14px] text-[#6b7280]">Excess Coin: 500.00 USDT</div>
              </div>
            </Card>

            {/* ETH Card */}
            <Card className="p-[16px] border border-[#e5e7eb] rounded-[8px] shadow-none">
              <div className="flex justify-between items-center mb-[12px]">
                <div className="flex items-center">
                  <div className="w-[20px] h-[20px] bg-[#627eea] rounded-full mr-[8px]"></div>
                  <span className="font-bold text-[16px]">ETH</span>
                </div>
                <span className="text-[#22c55e] text-[14px]">+1.2%</span>
              </div>
              <div className="mb-[12px]">
                <div className="text-[14px] text-[#6b7280]">Balance</div>
                <div className="font-bold text-[18px]">3.20 ETH</div>
              </div>
              <div className="mb-[12px]">
                <div className="text-[14px] text-[#6b7280]">Current Rate</div>
                <div className="font-bold text-[16px]">US $3,450.00</div>
              </div>
              <div>
                <div className="text-[14px] text-[#6b7280]">Excess Coin: 1.50 ETH</div>
              </div>
            </Card>

            {/* Add New Coin Card */}
            <Card className="p-[16px] border border-[#e5e7eb] rounded-[8px] flex items-center justify-center shadow-none">
              <div className="text-center">
                <div className="w-[40px] h-[40px] bg-[#f3f4f6] rounded-full flex items-center justify-center mx-auto mb-[8px]">
                  <Plus className="h-[24px] w-[24px] text-[#9ca3af]" />
                </div>
                <div className="text-[14px] text-[#6b7280]">Add New Coin</div>
              </div>
            </Card>
          </div>
        </div>

        {/* Transaction History */}
        <div className="mb-[32px]">
          <h2 className="text-[20px] font-bold mb-[16px]">Transaction History</h2>
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="border-b border-[#e5e7eb] text-[14px] text-[#6b7280]">
                  <th className="text-left p-[8px] font-medium">Date</th>
                  <th className="text-left p-[8px] font-medium">Platform</th>
                  <th className="text-left p-[8px] font-medium">Coin</th>
                  <th className="text-left p-[8px] font-medium">Type</th>
                  <th className="text-left p-[8px] font-medium">Amount</th>
                  <th className="text-left p-[8px] font-medium">Value (KRW)</th>
                  <th className="text-left p-[8px] font-medium">Status</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-[#e5e7eb]">
                  <td className="p-[8px] text-[14px]">
                    <div>2025-05-12</div>
                    <div className="text-[12px] text-[#6b7280]">14:50</div>
                  </td>
                  <td className="p-[8px]">
                    <span className="bg-[#f7931a]/20 text-[#f7931a] text-[12px] px-[8px] py-[4px] rounded-[4px]">
                      Binance
                    </span>
                  </td>
                  <td className="p-[8px] text-[14px]">BTC</td>
                  <td className="p-[8px] text-[14px] text-[#22c55e]">Buy</td>
                  <td className="p-[8px] text-[14px]">0.05 BTC</td>
                  <td className="p-[8px] text-[14px]">₩3,350,000</td>
                  <td className="p-[8px]">
                    <span className="bg-[#22c55e]/20 text-[#22c55e] text-[12px] px-[8px] py-[4px] rounded-[4px]">
                      Completed
                    </span>
                  </td>
                </tr>
                <tr className="border-b border-[#e5e7eb]">
                  <td className="p-[8px] text-[14px]">
                    <div>2025-05-09</div>
                    <div className="text-[12px] text-[#6b7280]">09:18</div>
                  </td>
                  <td className="p-[8px]">
                    <span className="bg-[#3b82f6]/20 text-[#3b82f6] text-[12px] px-[8px] py-[4px] rounded-[4px]">
                      Payful
                    </span>
                  </td>
                  <td className="p-[8px] text-[14px]">BTC</td>
                  <td className="p-[8px] text-[14px] text-[#ef4444]">Sell</td>
                  <td className="p-[8px] text-[14px]">0.02 BTC</td>
                  <td className="p-[8px] text-[14px]">₩1,120,000</td>
                  <td className="p-[8px]">
                    <span className="bg-[#22c55e]/20 text-[#22c55e] text-[12px] px-[8px] py-[4px] rounded-[4px]">
                      Completed
                    </span>
                  </td>
                </tr>
                <tr className="border-b border-[#e5e7eb]">
                  <td className="p-[8px] text-[14px]">
                    <div>2025-05-08</div>
                    <div className="text-[12px] text-[#6b7280]">18:45</div>
                  </td>
                  <td className="p-[8px]">
                    <span className="bg-[#f7931a]/20 text-[#f7931a] text-[12px] px-[8px] py-[4px] rounded-[4px]">
                      Binance
                    </span>
                  </td>
                  <td className="p-[8px] text-[14px]">ETH</td>
                  <td className="p-[8px] text-[14px] text-[#22c55e]">Buy</td>
                  <td className="p-[8px] text-[14px]">1.0 ETH</td>
                  <td className="p-[8px] text-[14px]">₩4,150,000</td>
                  <td className="p-[8px]">
                    <span className="bg-[#22c55e]/20 text-[#22c55e] text-[12px] px-[8px] py-[4px] rounded-[4px]">
                      Completed
                    </span>
                  </td>
                </tr>
                <tr className="border-b border-[#e5e7eb]">
                  <td className="p-[8px] text-[14px]">
                    <div>2025-05-05</div>
                    <div className="text-[12px] text-[#6b7280]">10:22</div>
                  </td>
                  <td className="p-[8px]">
                    <span className="bg-[#22c55e]/20 text-[#22c55e] text-[12px] px-[8px] py-[4px] rounded-[4px]">
                      KuCoin
                    </span>
                  </td>
                  <td className="p-[8px] text-[14px]">USDT</td>
                  <td className="p-[8px] text-[14px] text-[#22c55e]">Buy</td>
                  <td className="p-[8px] text-[14px]">500 USDT</td>
                  <td className="p-[8px] text-[14px]">₩500,000</td>
                  <td className="p-[8px]">
                    <span className="bg-[#ca8a04]/20 text-[#ca8a04] text-[12px] px-[8px] py-[4px] rounded-[4px]">
                      Pending
                    </span>
                  </td>
                </tr>
                <tr className="border-b border-[#e5e7eb]">
                  <td className="p-[8px] text-[14px]">
                    <div>2025-05-04</div>
                    <div className="text-[12px] text-[#6b7280]">13:10</div>
                  </td>
                  <td className="p-[8px]">
                    <span className="bg-[#3b82f6]/20 text-[#3b82f6] text-[12px] px-[8px] py-[4px] rounded-[4px]">
                      Payful
                    </span>
                  </td>
                  <td className="p-[8px] text-[14px]">BTC</td>
                  <td className="p-[8px] text-[14px] text-[#ef4444]">Sell</td>
                  <td className="p-[8px] text-[14px]">0.03 BTC</td>
                  <td className="p-[8px] text-[14px]">₩1,910,000</td>
                  <td className="p-[8px]">
                    <span className="bg-[#ef4444]/20 text-[#ef4444] text-[12px] px-[8px] py-[4px] rounded-[4px]">
                      Failed
                    </span>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* Exchange Coin Form */}
        <div>
          <h2 className="text-[20px] font-bold mb-[16px]">Exchange Coin</h2>
          <div className="border border-[#e5e7eb] rounded-[8px] p-[16px]">
            <div className="mb-[16px]">
              <label className="block text-[14px] font-medium mb-[8px]">From Coin</label>
              <div className="relative">
                <select className="w-full p-[8px] border border-[#e5e7eb] rounded-[4px] appearance-none text-[14px]">
                  <option>Select coin</option>
                </select>
                <ChevronDown className="absolute right-[8px] top-1/2 transform -translate-y-1/2 h-[16px] w-[16px] text-[#6b7280]" />
              </div>
            </div>

            <div className="mb-[16px]">
              <label className="block text-[14px] font-medium mb-[8px]">Amount</label>
              <input
                type="text"
                placeholder="0.00"
                className="w-full p-[8px] border border-[#e5e7eb] rounded-[4px] text-[14px]"
              />
            </div>

            <div className="mb-[16px]">
              <label className="block text-[14px] font-medium mb-[8px]">Rate Option</label>
              <div className="flex justify-between items-center">
                <span className="text-[14px]">Market Rate</span>
                <div className="flex items-center">
                  <Switch className="data-[state=checked]:bg-[#f6b10a]" />
                  <span className="ml-auto text-[14px]">Limit</span>
                </div>
              </div>
            </div>

            <div className="mb-[16px]">
              <label className="block text-[14px] font-medium mb-[8px]">To Coin</label>
              <div className="relative">
                <select className="w-full p-[8px] border border-[#e5e7eb] rounded-[4px] appearance-none text-[14px]">
                  <option>Select coin</option>
                </select>
                <ChevronDown className="absolute right-[8px] top-1/2 transform -translate-y-1/2 h-[16px] w-[16px] text-[#6b7280]" />
              </div>
            </div>

            <div className="mb-[16px]">
              <label className="block text-[14px] font-medium mb-[8px]">Excess Coin</label>
              <div className="relative">
                <select className="w-full p-[8px] border border-[#e5e7eb] rounded-[4px] appearance-none text-[14px]">
                  <option>Select a coin</option>
                </select>
                <ChevronDown className="absolute right-[8px] top-1/2 transform -translate-y-1/2 h-[16px] w-[16px] text-[#6b7280]" />
              </div>
            </div>

            <Button className="w-full bg-[#f6b10a] hover:bg-[#f6b10a]/90 text-white h-[40px] rounded-[4px] text-[14px]">
              Execute Buy Trade
            </Button>
          </div>
        </div>
      </main>
    </div>
  )
}
